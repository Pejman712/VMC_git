ICP Workshop

Install Python 3 and NumPy (python -m pip install numpy).
Complete registration(source, target) in registration.py.
Run: python registration.py
Or run the included NumPy ICP sample: python sample_solution.py
Import transformations.json into the ICP Workshop page.

sequence.json and scans/*.csv contain the same 50 ordered scans.
Coordinates: metres; x forward, y left, z up, in each sensor frame.
Return a 4x4 rigid transform from current scan to previous scan.
Map frame = scan 00; T_map_current = T_map_previous @ T_previous_current.
The identity baseline runs, but does not correct for robot motion.
